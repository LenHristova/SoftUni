﻿namespace P04_WorkForce.Models
{
    public class PartTimeEmployee : Employee
    {
        public PartTimeEmployee(string name) : base(name)
        {
        }

        public override int WorkHoursPerWeek => 20;
    }
}
