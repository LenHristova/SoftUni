﻿using P04_WorkForce.Contracts;

namespace P04_WorkForce.Models
{
    public interface IToDoBoard
    {
        event WeekPassedEventHandler WeekPassedEvent;

        void AddJob(IJob job);

        void WeekPass();

        void PrintStatus();
    }
}