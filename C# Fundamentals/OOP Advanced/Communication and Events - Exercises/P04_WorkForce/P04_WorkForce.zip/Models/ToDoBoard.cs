﻿using System;
using System.Collections.Generic;

using P04_WorkForce.Contracts;

namespace P04_WorkForce.Models
{
    public delegate void WeekPassedEventHandler();

    public class ToDoBoard : IToDoBoard
    {
        private readonly ICollection<IJob> _jobs;
        private readonly IWriter _writer;

        public ToDoBoard(IWriter writer, params IJob[] jobs)
        {
            _writer = writer;
            _jobs = new List<IJob>();
            SetJobs(jobs);
        }

        private void SetJobs(params IJob[] jobs)
        {
            foreach (var job in jobs)
            {
                AddJob(job);
            }
        }

        public event WeekPassedEventHandler WeekPassedEvent;

        public void AddJob(IJob job)
        {
            _jobs.Add(job);
            WeekPassedEvent += job.Update;
            job.JobDoneEvent += OnComplete;
        }

        private void OnComplete(object sender)
        {
            var job = (IJob) sender;
            _jobs.Remove(job);
            WeekPassedEvent -= job.Update;
            job.JobDoneEvent -= OnComplete;
        }

        public void WeekPass()
        {
            WeekPassedEvent?.Invoke();
        }

        public void PrintStatus()
        {
            _writer.WriteLine(string.Join(Environment.NewLine, _jobs));
        }
    }
}
