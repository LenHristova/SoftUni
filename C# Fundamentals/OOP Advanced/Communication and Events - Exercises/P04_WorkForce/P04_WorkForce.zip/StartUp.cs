﻿using System;
using System.Collections.Generic;

using P04_WorkForce.Contracts;
using P04_WorkForce.Core;
using P04_WorkForce.IO;
using P04_WorkForce.Models;

namespace P04_WorkForce
{
    class StartUp
    {
        static void Main()
        {
            IReader reader = new ConsoleReader();
            IWriter writer = new ConsoleWriter();
            IToDoBoard toDoBoard = new ToDoBoard(writer);
            ICollection<IEmployee> employees = new List<IEmployee>();
            IEmployeeFactory employeeFactory = new EmployeeFactory();
            var engine =new Engine(toDoBoard, reader, writer, employeeFactory, employees);
            engine.Run();
        }
    }
}
