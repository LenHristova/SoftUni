﻿namespace P04_WorkForce.Contracts
{
    public interface INameable
    {
        string Name { get; }
    }
}
