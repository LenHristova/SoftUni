﻿namespace P04_WorkForce.Contracts
{
    public interface IReader
    {
        string ReadLine();
    }
}