﻿using System.Collections.Generic;
using System.Linq;

using P04_WorkForce.Contracts;
using P04_WorkForce.Models;

namespace P04_WorkForce.Core
{
    public class Engine
    {
        private readonly IToDoBoard _toDoBoard;
        private readonly ICollection<IEmployee> _employees;
        private readonly IEmployeeFactory _employeeFactory;
        private readonly IReader _reader;
        private readonly IWriter _writer;

        public Engine(IToDoBoard toDoBoard, IReader reader, IWriter writer, IEmployeeFactory employeeFactory, ICollection<IEmployee> employees)
        {
            _reader = reader;
            _writer = writer;
            _employeeFactory = employeeFactory;
            _employees = employees;
            _toDoBoard = toDoBoard;
        }
        //public Engine(IServiceProvider serviceProvider)
        //{
        //    _calculator = (ICalculator)serviceProvider.GetService(typeof(ICalculator));
        //    _reader = (IReader)serviceProvider.GetService(typeof(IReader));
        //    _writer = (IWriter)serviceProvider.GetService(typeof(IWriter));
        //}

        public void Run()
        {
            string input;
            while ((input = _reader.ReadLine()) != "End")
            {
                var commandArgs = input?.Split();
                var command = commandArgs?[0];

                if (command.Contains("Employee"))
                {
                    CreateEmployee(commandArgs, command);
                }
                else if(command == nameof(Job))
                {
                    AddJob(commandArgs);
                }
                else if (command == "Status")
                {
                    _toDoBoard.PrintStatus();
                }
                else if (input == "Pass Week")
                {
                    _toDoBoard.WeekPass();
                }
            }
        }

        private void AddJob(string[] commandArgs)
        {
            var name = commandArgs[1];
            var requaredHours = int.Parse(commandArgs[2]);
            var employee = _employees.FirstOrDefault(e => e.Name == commandArgs[3]);

            if (employee != null)
            {
                var job = new Job(name, requaredHours, employee, _writer);

                _toDoBoard.AddJob(job);
            }
        }

        private void CreateEmployee(string[] commandArgs, string command)
        {
            var employeeType = command;
            var employeeName = commandArgs[1];
            var employee = _employeeFactory.CreateEmployee(employeeType, employeeName);
            _employees.Add(employee);
        }
    }
}