﻿using System;
using System.Linq;
using System.Reflection;

using P04_WorkForce.Contracts;

namespace P04_WorkForce.Core
{
    public class EmployeeFactory : IEmployeeFactory
    {
        public IEmployee CreateEmployee(string employeeType, string name)
        {
            var type = Assembly.GetExecutingAssembly()
                .GetTypes()
                .FirstOrDefault(t => t.Name == employeeType);

            if (type == null)
            {
                throw new InvalidOperationException($"Invalid employee type: \"{employeeType}\"");
            }

            var m = new object[] { name };
            var employee = (IEmployee)Activator.CreateInstance(type, m);
            return employee;
        }
    }
}
