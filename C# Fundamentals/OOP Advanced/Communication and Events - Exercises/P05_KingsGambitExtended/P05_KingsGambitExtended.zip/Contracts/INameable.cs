﻿namespace P05_KingsGambitExtended.Contracts
{
    public interface INameable
    {
        string Name { get; }
    }
}
