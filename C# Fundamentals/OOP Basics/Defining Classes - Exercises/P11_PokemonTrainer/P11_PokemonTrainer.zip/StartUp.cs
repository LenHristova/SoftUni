﻿using System;
using System.Collections.Generic;
using System.Linq;

class StartUp
{
    static void Main()
    {
        var trainers = new Dictionary<string, Trainer>();

        string input;
        while ((input = Console.ReadLine()) != "Tournament")
        {
            //info in format: <TrainerName> <PokemonName> <PokemonElement> <PokemonHealth>
            var info = input
                .Split(new[] { ' ', '\t', '\n' }, StringSplitOptions.RemoveEmptyEntries);

            var trainerName = info[0];
            var pokemonName = info[1];
            var pokemonElement = info[2];
            var pokemonHealth = int.Parse(info[3]);

            if (!trainers.ContainsKey(trainerName))
            {
                trainers.Add(trainerName, new Trainer(trainerName));
            }

            var currentPokemon = new Pokemon(pokemonName, pokemonElement, pokemonHealth);
            AddPokemonByElement(trainers[trainerName], currentPokemon);            
        }

        string command;
        while ((command = Console.ReadLine()) != "End")
        {
            var element = command;
            foreach (var trainer in trainers.Values)
            {
                if (HasPokemonFromThisElement(element, trainer))
                {
                    trainer.BadgesCount++;
                }
                else
                {
                    trainer.DecreasePokemonsHealth();
                }
            }
        }

        foreach (var trainer in trainers.Values.OrderByDescending(t => t.BadgesCount))
        {
            Console.WriteLine(trainer);
        }
    }

    private static bool HasPokemonFromThisElement(string element, Trainer trainer)
    {
        switch (element.ToLower())
        {
            case "fire":
                if (trainer.FirePokemons.Count > 0)
                    return true;
                break;
            case "water":
                if (trainer.WaterPokemons.Count > 0)
                    return true;
                break;
            case "electricity":
                if (trainer.ElectricityPokemons.Count > 0)
                    return true;
                break;
        }

        return false;
    }

    private static void AddPokemonByElement(Trainer trainer, Pokemon pokemon)
    {
        switch (pokemon.Element.ToLower())
        {
            case "fire":
                trainer.FirePokemons.Add(pokemon);
                break;
            case "water":
                trainer.WaterPokemons.Add(pokemon);
                break;
            case "electricity":
                trainer.ElectricityPokemons.Add(pokemon);
                break;
                default:
                    trainer.OtherPokemons.Add(pokemon);
                    break;
        }
    }
}